import React from 'react';

export function Education() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Education</h2>
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-8">
          <div className="mb-8">
            <h3 className="text-xl font-semibold">Bachelor of Technology in Computer Science</h3>
            <p className="text-gray-600">Malla Reddy Engineering College For Women • 2022 - 2026</p>
            <p className="text-gray-600 mt-2">CGPA: 8.7/10</p>
          </div>
          <div>
            <h4 className="font-semibold mb-2">Key Courses</h4>
            <ul className="grid grid-cols-2 gap-2 text-gray-600">
              <li>• Data Structures & Algorithms</li>
              <li>• Database Management Systems</li>
              <li>• Operating Systems</li>
              <li>• Computer Networks</li>
              <li>• Machine Learning</li>
              <li>• Web Development</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}