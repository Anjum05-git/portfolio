import React from 'react';
import { Code2, Globe, Database, Server } from 'lucide-react';

export function Skills() {
  const skills = [
    {
      icon: Code2,
      title: "Programming",
      description: "Java, Python, JavaScript, TypeScript"
    },
    {
      icon: Globe,
      title: "Web Development",
      description: "React, Node.js, HTML/CSS"
    },
    {
      icon: Database,
      title: "Databases",
      description: "MySQL, MongoDB"
    },
   
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Technical Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
              <skill.icon className="mx-auto mb-4 text-blue-600" size={32} />
              <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
              <p className="text-gray-600">{skill.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}