import React from 'react';
import { User, MapPin, Calendar } from 'lucide-react';

export function About() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">About Me</h2>
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="w-full md:w-1/3">
             
            </div>
            <div className="w-full md:w-2/3">
              <div className="flex items-center gap-2 mb-4">
                <User className="text-blue-600" size={20} />
                <span className="text-gray-600">Computer Science Student</span>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="text-blue-600" size={20} />
                <span className="text-gray-600">Hyderabad, India</span>
              </div>
              <div className="flex items-center gap-2 mb-6">
                <Calendar className="text-blue-600" size={20} />
                <span className="text-gray-600">Final Year Student</span>
              </div>
              <p className="text-gray-700 mb-6">
                I am a passionate Computer Science student with a strong foundation in software development
                and a keen interest in machine learning and artificial intelligence. Through my academic
                journey and personal projects, I've developed expertise in various programming languages
                and frameworks, always striving to create efficient and innovative solutions.
              </p>
              <p className="text-gray-700">
                Currently seeking opportunities to apply my skills in a challenging role that allows me
                to contribute to meaningful projects while continuing to learn and grow as a developer.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}