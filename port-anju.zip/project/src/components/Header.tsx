import React from 'react';
import { Github, Linkedin, Mail } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
      <div className="container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">SHAIK ANJUM</h1>
          <p className="text-xl md:text-2xl mb-8">BTech Computer Science Student</p>
          <p className="text-lg opacity-90 mb-8">Passionate about building scalable applications and exploring new technologies</p>
          <div className="flex justify-center space-x-4">
            <a href="https://github.com/" className="hover:text-blue-200 transition-colors">
              <Github size={24} />
            </a>
            <a href="www.linkedin.com/in/anjum-shaik-47272024a" className="hover:text-blue-200 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="shaikanjumanju@gmail.com" className="hover:text-blue-200 transition-colors">
              <Mail size={24} />
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}