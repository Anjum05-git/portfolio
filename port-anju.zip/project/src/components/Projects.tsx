import React from 'react';
import { ExternalLink } from 'lucide-react';

interface Project {
  title: string;
  description: string;
  tech: string;
  link: string;
  image: string;
}

export function Projects() {
  const projects: Project[] = [
    {
      title: "Ayurvedic leaf identification using machine learning and deep learning ",
      description: "Ayurvedic leaf identification using machine learning (ML) and deep learning (DL) leverages computer vision techniques to analyze images of leaves and identify the corresponding Ayurvedic plant species. This approach aims to improve the accuracy and speed of plant identification, crucial for traditional medicine and botanical research. .",
      tech: "Python, Deep Learnig, Machine Learning",
      link: "https://github.com/yourusername/face-recognition",
      image: "https://ars.els-cdn.com/content/image/1-s2.0-S2405844023108632-gr1.jpg"
    },
    {
      title: "Fraud Dectection in health care insurance claim",
      description: "Healthcare insurance fraud detection involves identifying and preventing dishonest practices used to obtain unauthorized benefits from insurance companies. This includes a range of activities like fabricating diagnoses, inflating claims, identity theft, and non-disclosure of pre-existing conditions.",
      tech: "Python, Jupiter notebook, Random Forest",
      link: "https://github.com/yourusername/self-harm-prediction",
      image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATMAAACkCAMAAADMkjkjAAAB4FBMVEX///+oxf19p/3p8PrT4v/7Un0mbfv3+P0XQZfk6vZRivvk7Pnu9PrKz+Wsyf06evseavtfjfpLgvv6JV3a5f7ySHkAYfrT2OtDfvuLsf0TZvuduPnN0ufg5vQAAAB/qv3FVBxqmfz7Snj7FVbq5/T/6/D7Z43+xtH9oLT/9/m1zv2Rtv0AN5Hxs4QAGFr7QnP9ucgAE1gAHFzA1f6gv/3V1dXL3f78kqk8O23Dw8Ph6/4ADFYaPo4AOJGzs7OTk5NFRUXu2OYNJ1mxv94lHlHs7OxERETwzNz8dZb+4umuuMsaNWtMXoYAJWI3NIJ6h6XAQgDudZrvmmEALY+fsNOSr+pph8n7tn26YED7PGz8AEfl3ODzgZsAU/8wMDCPjo0gICBnZ2d8fHzvtszbts/6jKrxxtj1qMA3TXyJla9cbJGSkbd9e6kYE3csKH4AAHCjosEwMIKifIJycKRSRoLfp4PjtqTIXyq+OwDRflzkwbH0wp/smbXXfUr42MLsjU0eWczjl2i6kp9ifLwcULnQkX3CfmvTjGtOWahiZ6xrj+QAScKdqNb6Yn70nIL6zMbJrrL3g4CyoL1vbIGHltmshnf20rhWc83AZ00lUaO7f3pAdNxWdr2Yrdl0jcRXeL7BQU6NAAAU1ElEQVR4nO2d/V8TSZ7Hk3RDiOnEB5rJAAkgT0IgCXkgrglBYQaJeRB8GvTwdO88R0BnzpnZkXPRGV1Xl3HZO3Zld4bRYf/Vq6qu7lT1Q1LdeZx95fODJiFNync+34eq6m5ttrbaaqutttpqq6222mLUpclmj+DXprFb/zZyptmDaHk5UwLxLNuxfru7aWP5tSj57/bzd87Z5u/MwmeT5wbm28FZSUsrs3cHBpbmB2bn523z8+cGzp+ft9lm755favbIWlezA/PnBwYuAGYX7tjuXDg3MPDbgbtLAxfuXGj2yFpXiNldAGr2wkXbRcBs3nbxzvmB8/8xMNvsobWsELOl/xyAPluCPrtru3MRMJtvB6ehALO7A0u2iwOzgNsAjM2Bgfml34KHzR5Z62rp3NLsOfSXbX52dhb8fQ4EpfPcuWYP7FchwQn/nJyU/2glOZs9AEreYFwMxqF4bzxut52dAXpwf2ZmYqzZQyOUavYAKMXFfm88EQzGg1zcm0ymzkycOXN25szMg5lLzR5aSU6+2SOoqFaLTFuq9Zm1mpx8m5lZiW1mZsXxbWZmxbeZmVWqzcysnHybmVmJbWZmJfBtZmbFt5mZVarNzKycfJuZWYltZmbl5tvMTEqJzDYzZoltZmZVikw+2eyx/EpERCbvbcYAxOMfa+XoZdEp7YHHE40YskJMDNob8HnaAXx0QqO+0w4WdeocOVX/EZORaW8Ss06NTpweZGKmVV9/3QdMRWabGduAS8iC9mYysxabfdRBJxrCLEVFZhOZHVdldyabOQbpg06eaAAzjo7M5jE7cdIpkHImHIMMcqsO6qs/MyKZiTAym8lM4Gi5ucpSvUfobwAzURWZrcTMghrBjEhmvL3NjEWcJjLbzCqI7Mzi9jYzpqFqklmbWQXpJLN/DWb1m28S00w++K/CbOqjvhP185lA5P+4vQWZjbrM4QIdrdPpFlNurl7nt5L5P2lvQWYLC6ysnI06B5jI/9KcqUWYuSRxy/dYgDV2lPrJrPnMPH6k/7rv9wSsM5skVaNBEiWTSmbNZ+YHwcYJC9kFwWeG2eTYpeUzMw8mzt6+nR0fH+8gND6ezd4+OzGzXN1FxmTJTNpbjNnCsjCavc9xCjOfoQLg2LEHZ7PjHcPDw5HIMFKHVuh18OOO7IRVblwZZM1nJtxfnhhfYGHmh8zO3NLFpK/hWxavKyC6DFX+bwlm3PI4tFmJmVwXtIIXXp9hJwYUsXY9O9lliBpkLcCMu5L9nGTmMRT02YwpZsMzVsZHIlOVzFZh9iDLEcyE8j4zyeyBlfGRLotrkbUCs4UHAukzn99IsG6aZDZhZXgEMk3+bxFm3CjHMdVNCz6zwIzsZXWRNZ2ZgMKRqgGGgpOmujMjkfG6yJrNzKMEHsM8wAKzs6bHVrbLaAlmOLvD/STBFQBeEwTjNSIjZsPDRu2taWYsyJrNTCqVQiC3slEMQxULmx6XATbITKc/G8e/dkz7I7PMKGQ6XUarMBOE3FYxGo5G00BRoHR+xe/Uw4aYRerIjEQmGiJrPjMhlwfA8lubOb8v4PPkNgvgebrg14FmgZmpGsDmsqYzE3wb0Vh6KxfAqQ2+FsgV0rHoCqehBpldqh8zymV6vWxrMBM208XYik/V+rs5TyEaznvU0CCzMXPMTMwDmJHVmZn/4aNHD3M+9egUZlvR2IZHb7LE5YqxcE4FDfa0k+aYsc83qcAsi6y+zB598SXUfz9UDU9mVghHV9z680suUAinNwUtM1N1k31dg2dHVldmni8uX7785ZeXH6tel5lthaObRjNyaMJwmnYaugkfsSgrdWURhZm8DFliF2FcP3OaQVZXZo++uvzV5a9Da+rX8flnK9GyyDgBMKVzGjw4qwDJnsHCv3ZSfn5WgTbMxswcsroy++arr373bSgUUi8wS8xy6fCK4bqPxKgQy7vUzO7LQIx7L2KuwHTPHHIhu0L6rzuzx1/+LgSlfh0xO5aPFTg1KDeFjHPlw1uCitmEGWbjpRefbK+urj7Re7vbnMvqy8z1xbeGzDr/uBjz0R3G6LMr9zgSGeh301GPqtmYMcMsq7z25H+GgFafat+dMumyOtfN3yNkO+qXEbPFmCqZjfb09ESeuQlkKKUVBJrZJRPMiLc8fT6EoGmcRvUYZSZMjWKGkIW+0wwTMOtazKsC81kP1IKbzGCCL5YmZlGoqTXDrNSebYdeImjb6rFQgcmErK7MJr+/evXljsZmiFlRZTP3AkLWc8VNLWf7CrGt0mI3ao472JlFlpXXtsGXh4xGfYN0wWREVi9myYQ9mHzy/fdXv9epXIDZi8VYgLbZFYlZZDlAKRct+krP4NG3h9mZlSr29suQ5DQyo3E0MqP1ssYw404hHfzhTy91fgqYdRXpoun+PNLTcxtxo5kF8uEczUwhMj4hSZ5TTuLnE0oLR5RNyCz0nDYalf0N1v4bx6z3mKyTp+1uHWbF4iu6AowDizmdANnIMz+5p+nfCm+VXoAzgdLKBu76S/MA1TSAdOL28xCOTsVookVk9WFmP32spFMfn1ZRA8wWi29JZu4HwGaRybGenu7u7lFqkvk4WlDNntTTSsP5ZoSYoQ/BhPZyu2Q0OpXpb8rpa7AeyEQHyQxQ61Uze6FiNopS2dilnlvd3SNXSKP5r4fz8mMfnj0NMzIbJnIpgAUq0rZiNLqRZWrLJHl7HXVAJjgcJylmx07qMDtNMOPuI2YLCxFgs+6RZVcpg7n8xbTyWGKm3kYxZEakM8js6tWrQ3LppOOSrS2T1OuoB7N+h4NGduyUQL1B/OiPi3MEM9xnAGYjiNk4OV8KAGYGXW0FZuQi7eTq6nOF2dASjYy1x4Aum3LUg1nSoWVG39JVwyyLmV1CzLpH7hHQXPm0T5XQxtmYkQtBS098PhCbT4dWV2++3n9NZ3/WHgMjqz0zwaHDDN1eQTl5WMXMfS+CWzPMrPsWZ8SMnqZXiE1iVG53in/zp69f+dbXXW73qN9awZSQ1Z4ZiExVCcDMnE4ZGmRG5LOA1M323FKYjTwrGQ3EJjmb0tlHGb+ENLZMMyNDM+B2i8nd3d090Y0UKCFjz/52e7+jLsxEeDFvRWZkDeCeDUvMujvGMTOy3/CHY+RVmyg4sxScjgiWKp2VQtMJmfE/7O4mMTO30s6ayP4yspozQ5dInzRi5sTMyP5sVLbZyPCwjGwkq0DKpTeofg3+ApaTNoZL60C2QABSerX7SkxhZm7RbCqz2xOO+jCDBcBh1+QzkWLG/3lusfgZp5podt+y2W4p0JZlX61EqWVHFJw6GylqYuT2idMXgJReKaEJZa4rA7lMdhlgJtb0sg4e/MopG+Ez9PCU2ybHptO/uZFeXFwsbnG4z4jgyOzuHhvrVpgp/cZGVLVlBz9mogK0v/zvX4jmLBBAzI52k6kSs5S5uLSXkDlsPF/TyzuAgQ+WTqmZ4e8lkNvKp2PFImSGl8/cyxEZGaVbGJQvHfNRyOhFNCOFQv+nDEmQmKWOfpBshsExL2OoXIaY8bW0mrN3f21fzQzOAwTPSj4dLhaL4ehG14sXi9EcR6SzWypkI/fl0AxvqLfT4cdUMtpfQzvKOlBAYuY+2pOQ7T91ob8tukxixvOapQfr+m5t7W8kMwjtdGCzUIwCg8WKG+9yS3DNcU5eDHIvw2Q2opJcA1x5dWiyGS3yJBTakSbjgi/g4wEj7siDma3eHIUP2BszymUyM14UypMwoZ21AzL/Q2bvkcFi4Y2/h9b+Ia3TvlgMY6OBFlMj+fwWYTOc59RCQ31QFhoompM7a6HQuhPZTNxHzHAie706NLQOExwzsymHHjOeT9UqQCfXqPbsR8hs7vBw493++o602cnDPZS54kZpjm6kQDG6qT2pCo20rM1Qb/ZdaG3fFwDzfd6zzQFmD3GX8QZupYAHrFXTq0LmIE5UqFWArh9TM4P629raWmgHZBmnEzEDRlO2hI2QCYXYht7r8FN0TkQrRaa0dDsZ8sNcJvL7T900syGQ4HwWXUYx48XaVNAkkc6OHe5KjcfH+6F/wPwCOw4e7aOvxOToNES2GU5rTqhSjHbWMDqVlVubByHjPU+J2OR/Ghp6A3z3E6PLetXIHPQJMTWpoAmS2XXPj+/f//j2xicC7moVZsJGsejntMhKu0yP0+EV3SssPGiY40bMSmccyFOkJyVmKeCz1ZfrqdfbbMy0yFTMqqfmzK28J5CdttlcAQ7+b03OkjCzQL6YB9A0OUy+8vBxLLYV0L+6Am2mqNfRlMiUZwCcskwGWzLukcxs9Xko9HroplVkGmZVFYPZzUI6WiSzWT/JSsVM8IFimtMEnrwquxmNFQJGcsGP009p8i6AQCwsojZWYiaK+6uh0MvVoZ9YelrdO4xpmYFPsEYsl0ct2CE50YyXYcYJvnwxvKk+b1baBvAUwrGCh9qCoiQ1HDrQIhMaYjzvLjFbX99/HroK2o2fKzNL6N+UzeZNilpqlkroSrgYS+dXyO7sFK+DTGHGCYGNcHgjp3MZRS4fA2W1nNBHTmigRaT9OdVuL6L1DUIGyvfa/h9+fvPmcSVi3oQuMcDMbg/yOtQseM2f3tgEiYYnSsCpZFlmQCvRWLiQ4whsfp9nEzr2sU/tLZ8Wmtpp2GWqcwoIZu7A73c8gAdDYPYbIIPM7Pa4ToBayGvSAde73jPGJpTghye251dyPg7dOs/le7wFZgzhlYBLm8QoZtLMZYaChhszTWFDsF7hhTO2JSBNJ6tiZvcma0MNam+6q+vw/fv3DLGJE1gBMIoW8xuFQmEjjx6v+BjujCNBu9RR2jcfxhVTHTdJOCkP7MprQEwTTb2CSTGD1HQC1NI09AgwkxXQs5maGUhrm1tFdNkOvIBnYyVndMGTLrTJ29hqkeyYLrKkPY58dsjJq9oMyMrdktOmvCuoZzULc4NXGQxsbu6aSw+Zhhm85snly+U2NzdzuQBX5so6XWi2Mx0RaDL5XBfVeRggcyVVzComM4OCqWFmRI13mwvR3QwmNtd1zcPIDIPTXq5TgVkQf6Mz45Hb2GRO6nqSJFqL5Qlm7srb5l7D7K9lBouBXoTyKRMh6jwsheb0dabYtCyhv1PEHytPl6g7Y8ir1yLNrNL+XJlUpsPMoITCysNqNg6H5hxktldvZn199JlNKR1idnuKYObiKxWBSsg0zOxeA2qs9SBwrcQsc1R3Zp19p0sZl4hLkdwhkZh1cfIuXTlmRo1sOWbGXmOLUQ/BrGu3/sw6+xzyqEiTUSnLrWJmXDjLdGXlmZWhVjlGr08TzLoawOyEQ4Qh4CTvJE4neS+C5cPMyhbOinFpzAxQ0+1yGbDtkcwyus1GzZmBQRkTA/2AhplB4SzfYlRkBj7JkFpZbHJLO4eKgK9BzAhiWg+hltbty5SY6RdOlrgsz8xoRoVllNs+yI0GZKbfoNWNmcjH9aIuSTEzbDaY4rISM1REdRs2PES9W3Yeksz0G7R6MdMEJcXMTzDTKZwM9ZKNmR2GaBlqwG5qbtcoZrrNRn2YGRED0wD0Zn8XPkoURW3hZDYZC7NKZitxQzw4ilnmFSszF+O9Vg2YJXWDEusTpOtd8I/rv1zfO9pT4fUyJn92Zvay9UCO0xQHb7Lr9FHMunYZ89noA+s+GxTjZSeQ3g/XoKa7pmV9UAFmTf6mmEGzVcSGwHkUZhI0oTwzfI8lz30Py71W9ZmdrrBM4SVmwEiZV9QR5kxmgpmErXyMQmq/TFPMdFeDCGZ+6R9/+57AcG9CzUI3I7MuNbPPyCNMmswcM3uZyajCbE/FTK/ZoJgtjHLc/SvE/c9c9AV3Bgqw+yyRMWZmMpNZYWaX3GZsN/EoQzGb/iUFhG7VpSCz0T67P3pv/HOm++zR28LMzG7gIX2QhzV9oPzMvMmsMJOwGVVS8ZWK2ZH6jaDSB/tIZvey2StcXZlJ1s8cKMxu4H+HFZNZZAY/LqjfgIgfCGZzMN3qvItmNprN3iOZGcejxRpwgJkl5FogMzPTk9WAGeKmY7fUbhfls67DVCVm3ER2lGO6P63PEjPvZ9LXeFiqn4hZvzWTVcdM5kb5jKjraJbeVdFn3PJZjmSGZzg6suYzL7b+h6DyfSYsh2UtmKFBwY4Xo0liZj8cYqNldNo6FbPRZZoZu9iY7eJiGZSXDw69lsOyVswkbnEELomr+RGsBagIfFKRGdptYroXviVm9kOcxLz/zEhf5IdqTFY7ZpKC8SDOsntwuVZa2dAGJ8HM1L1WLTKTzSUntsyP1SGrLTNQ1zGz6/y0lNCm98oyK1cVa8Qsgcpm5p+Y2VxX5m11yGrODH+VN7wfpDjIaBo0nuzPqhMTM6k9g/3FQYsyw1Mnu/cAB+eHoDcYjMfjSSS1zxrA7CCDa6U0OMCsSmT1Yua1J3DhPNS+aaqRzHAWg8s/vbhRqzKdOWyDUzVlJg1r12uHwYk6tGYzQ+3Z9IF3atAhDa7aEuCwORy1pHZDTrhSTMAikGgyM9RqZKYgKMQs87YGzGpJTUoe0mILZnajycyIeJTqU7UlQGJWO2oHSpGSghMuJzSXGfzqZG9JubZaZDIzRM3MRaBGzJDPpHiUKie9KKow6+w8VQMd76zEzHtjOpPJYE6HNSkBJWZANfAarpvSEzxTMWB2ogbqrMDMa596+827d+9w2j/MdE1PV10CKGYOR2+iSq9JzKT+AgfnoQGzWsmYmTcBp+L7a2v7CqZvv31SLTE1MxCi2jJnipnSDGGAc7BXaw4zPBPfD4WUVYzBnbX92jOrMrEhnykpTKpTmm+hAcxAUErEBgdfX5UxDToOvr26Vw9mDhiilqEdRT/99NPf4P7ixqdQR+p/U22Z9ekwS8jOenhzdXX1a4zvZ/B49aBOzKox22+QEuQTdYc2dbymcqhHWlq1frh98+bNbYzpDXh88+eqK4AhM4dls3mR9J6o31MzUb87QS3BDkKRj2uArAyzWrVsDZSSxeqrcsyAevubzcGE+qta5a8ZM2C2KgpCI5XobYTFkCoyg2p5bIkGOUwSEzPotv6WzW0NdJgkRmZQLYjN27AcRsoEMwespNVOSGsob6IhVVIrc8ygWqSUNsNgWOaZOZDdmsqrWQbD+n9qbYRzEe9FVAAAAABJRU5ErkJggg=="
    },
    {
      title: "Fine-Grained Object Detection in Aerial Images Using YOLO V5",
      description: "Implemented YOLO V5 for detecting and classifying small objects in aerial imagery with high accuracy. Enhanced model performance for real-world applications.",
      tech: "Python, YOLO V5, Computer Vision",
      link: "https://github.com/yourusername/aerial-object-detection",
      image: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <section className="bg-gray-100 py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Featured Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <p className="text-sm text-gray-500 mb-4">{project.tech}</p>
                <a 
                  href={project.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-blue-600 hover:text-blue-800 inline-flex items-center"
                >
                  View Project <ExternalLink size={16} className="ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}