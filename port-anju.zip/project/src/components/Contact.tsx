import React from 'react';

export function Contact() {
  return (
    <section className="bg-gray-100 py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Get In Touch</h2>
        <div className="max-w-xl mx-auto text-center">
          <p className="text-gray-600 mb-8">
            I'm currently looking for internship opportunities and would love to hear from you!
          </p>
          <a
            href="mailto:shaikanjumanju@gmail.com"
            className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Send Email
          </a>
        </div>
      </div>
    </section>
  );
}